"""Kafka channel plugin tests."""
